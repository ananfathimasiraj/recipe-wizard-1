from django.shortcuts import render
from itertools import combinations
from youtubesearchpython import VideosSearch
import requests
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()
YOUTUBE_API_KEY = os.getenv('YOUTUBE_API_KEY')

BASE_QUERY = "Cooking recipes with"

def search_youtube(query, max_results=5):
    """ Searches YouTube for videos based on the query. """
    if not YOUTUBE_API_KEY:
        print("❌ ERROR: YouTube API Key is missing!")
        return []

    url = f"https://www.googleapis.com/youtube/v3/search"
    params = {
        "part": "snippet",
        "q": query,
        "maxResults": max_results,
        "type": "video",
        "key": YOUTUBE_API_KEY
    }

    try:
        response = requests.get(url, params=params)
        data = response.json()

        if "items" not in data:
            print(f"❌ API Error: {data}")
            return []

        # Extract video details
        videos = [
            {
                "title": item["snippet"]["title"],
                "videoId": item["id"]["videoId"],
                "thumbnail": item["snippet"]["thumbnails"]["medium"]["url"]
            }
            for item in data["items"]
        ]

        return videos

    except Exception as e:
        print(f"❌ Exception in API call: {e}")
        return []
    
def chef(request):
    """ Handles ingredient-based searches and fetches YouTube videos. """
    if request.method == "POST":
        ingredients = request.POST.get("text", "").strip()

        if not ingredients:
            return render(request, 'punc.html', {'name': 'Error', 'string': "❌ Please enter at least one ingredient."})

        query = f"{BASE_QUERY} {ingredients}"
        videos = search_youtube(query, max_results=5)

        if not videos:
            return render(request, 'punc.html', {'name': 'Error', 'string': "❌ No recipes found. Try different ingredients!"})

        return render(request, 'punc.html', {'name': 'Recipes Found', 'videos': videos})

    return render(request, 'index.html')