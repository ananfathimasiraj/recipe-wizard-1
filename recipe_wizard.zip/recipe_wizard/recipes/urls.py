from django.urls import path
from .views import chef

urlpatterns = [
    path('', chef, name='index'),
    path('chef/', chef, name='chef'),
]
